#ifndef NATIVE_ANDROID_IMAGE_H
#define NATIVE_ANDROID_IMAGE_H

#define NATIVE_IMAGE_IS_VALID(x) (0 != (x))

#endif
