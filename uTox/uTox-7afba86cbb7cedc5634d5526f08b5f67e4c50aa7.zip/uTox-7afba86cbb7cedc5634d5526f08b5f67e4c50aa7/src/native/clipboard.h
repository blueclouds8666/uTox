#ifndef NATIVE_CLIPBOARD_H
#define NATIVE_CLIPBOARD_H

void copy(int value);
void paste(void);

#endif
