#ifndef LAYOUT_BACKGROUND_H
#define LAYOUT_BACKGROUND_H

typedef struct panel PANEL;
extern PANEL panel_root,
             panel_main,
             panel_chat,
             panel_overhead,
             panel_splash_page;

#endif // LAYOUT_BACKGROUND_H
