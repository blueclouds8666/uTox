#include "screen_grab.h"

void utox_screen_grab_desktop(bool video) {
    native_screen_grab_desktop(video);
}
