#ifndef WIN_EVENTS_H
#define WIN_EVENTS_H

#include <windef.h>

LRESULT CALLBACK WindowProc(HWND window, UINT msg, WPARAM wParam, LPARAM lParam);

#endif
