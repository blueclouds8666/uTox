#include "draw.h"

int font_small_lineheight, font_msg_lineheight;
