#ifndef THEME_TABLES_H
#define THEME_TABLES_H

#include "theme.h"

extern const char *COLOUR_NAME_TABLE[];
extern uint32_t *COLOUR_POINTER_TABLE[];

#endif
