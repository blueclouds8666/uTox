#define STB_IMAGE_IMPLEMENTATION
#include "../third-party/stb/stb_image.h"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "../third-party/stb/stb_image_write.h"
