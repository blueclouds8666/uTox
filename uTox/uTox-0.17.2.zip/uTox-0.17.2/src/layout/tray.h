#ifndef LAYOUT_TRAY_H
#define LAYOUT_TRAY_H

typedef struct panel PANEL;
extern PANEL panel_tray;

typedef struct button BUTTON;
extern BUTTON btn_tray_exit;

#endif // LAYOUT_TRAY_H
