#ifndef SCREEN_GRAB_H
#define SCREEN_GRAB_H

#include <stdbool.h>

void native_screen_grab_desktop(bool video);

void utox_screen_grab_desktop(bool video);

#endif
