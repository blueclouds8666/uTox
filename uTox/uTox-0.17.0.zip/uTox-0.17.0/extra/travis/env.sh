#!/bin/sh

export CACHE_DIR="$HOME/cache"

. ./extra/common/env.sh
