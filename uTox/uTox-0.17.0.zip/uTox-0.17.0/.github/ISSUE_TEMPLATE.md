### Overview

1. uTox version:
2. Operating system:
3. Desktop Environment/Window Manager (Linux/BSD only):

### Issue

Write your issue here.
