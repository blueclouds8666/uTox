#ifndef NATIVE_WIN_IMAGE_H
#define NATIVE_WIN_IMAGE_H

#define NATIVE_IMAGE_IS_VALID(x) (NULL != (x))
#define NATIVE_IMAGE_HAS_ALPHA(x) (x->has_alpha)

#endif
