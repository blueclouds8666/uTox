#ifndef NATIVE_UI_H
#define NATIVE_UI_H

void redraw(void);
void force_redraw(void);

void setscale(void);
void setscale_fonts(void);

#endif
