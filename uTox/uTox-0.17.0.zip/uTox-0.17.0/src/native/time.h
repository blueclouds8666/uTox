#ifndef NATIVE_TIME_H
#define NATIVE_TIME_H

uint64_t get_time(void);

#endif
