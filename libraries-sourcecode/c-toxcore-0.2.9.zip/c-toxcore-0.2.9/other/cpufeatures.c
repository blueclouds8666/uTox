#ifdef ANDROID_CPU_FEATURES
#define typeof __typeof__
#include ANDROID_CPU_FEATURES
#endif

extern int unused_declaration;
