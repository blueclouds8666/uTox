#!/bin/sh -e

echo 'Running autoreconf -if...'
(
  autoreconf -if
)
