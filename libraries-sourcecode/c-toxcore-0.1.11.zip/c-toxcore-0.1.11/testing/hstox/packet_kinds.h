#pragma once

#include <stdint.h>

extern uint8_t const packet_kinds[21];
