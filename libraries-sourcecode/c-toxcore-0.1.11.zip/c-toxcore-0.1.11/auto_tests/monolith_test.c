/* Auto Tests: One instance.
 */

#define _DARWIN_C_SOURCE
#define _XOPEN_SOURCE 600

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "../other/monolith.h"

int main(int argc, char *argv[])
{
    return 0;
}
